<?php
require "../core/function.php";
require "../core/db.php";

use Shuchkin\SimpleXLSX;

require "excel.php";



if (!empty($_FILES['file']) && $_FILES['file']['error'] == UPLOAD_ERR_OK) {
    // Be sure we're dealing with an upload
    if (is_uploaded_file($_FILES['file']['tmp_name']) === false) {
        throw new \Exception('Error on upload: Invalid file definition');
    }

    // Rename the uploaded file
    $uploadName = $_FILES['file']['name'];
    $ext = strtolower(substr($uploadName, strripos($uploadName, '.') + 1));

    $allow = ['xls', 'xlsx'];
    if (in_array($ext, $allow)) {
        if ($ext == "xls") {
            $filename = round(microtime(true)) . mt_rand() . '.xls';
        }

        if ($ext == "xlsx") {
            $filename = round(microtime(true)) . mt_rand() . '.xlsx';
        }
    } else {
        echo "File type not allowed";
        exit;
    }

    move_uploaded_file($_FILES['file']['tmp_name'], 'excel/' . $filename);
    // Insert it into our tracking along with the original name
    $file = "excel/" . $filename;
} else {
    $file = null;
}


if ($file == null) {
    echo "Format file not allowed";

    exit;
}

$a = post("a"); //3
$b = post("b"); //1 Name
$c = post("c"); //4 Job
$d = post("d"); //5 Position
$e = post("e"); //6 Company

if ($a && $b && $c && $d && $file) {
    $a = $a - 1;
    $b = $b - 1;
    $c = $c - 1;
    $d = $d - 1;
    $e = $e - 1;

    if ($xlsx = SimpleXLSX::parse($file)) {

        $i = 0;

        foreach ($xlsx->rows() as $elt) {
            if ($i >= $a) {
                $nama = $elt[$b];
                $job = $elt[$c];
                $position = $elt[$d];
                $phone = $elt[$e];
                $name = str_replace("'", "", $nama);
                $count = countDB("anggota_baru", "name", $name);

                if ($count == 0) {
                    mysqli_query($mysqli, "INSERT INTO anggota_baru VALUES (NULL, '$name', '$position', '$job', '$phone')");
                }
            }
            $i++;
        }
    } else {
        echo "Kesalahan parsing file";
        exit;
    }

    echo "Sukses input nomor";
}
