<?php
require '../middleware/header.php';
?>
<!-- Start Content-->
<div class="container-fluid">
    <div class="row">

    </div>
</div>
<script>
    page = 'change-password';
    document.getElementById("title").innerHTML = "Change Password | Spanel - Panel BOT Automate sEntra UTama ";
</script>
<?php
require '../middleware/footer.php';
