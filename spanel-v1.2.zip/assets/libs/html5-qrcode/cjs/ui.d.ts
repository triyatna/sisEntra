export declare class LibraryInfoContainer {
    private infoDiv;
    private infoIcon;
    constructor();
    renderInto(parent: HTMLElement): void;
}
