export declare class CameraManager {
    static hasCameraPermissions(): Promise<boolean>;
}
