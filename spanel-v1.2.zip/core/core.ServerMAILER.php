<?php
require 'core.Emailsent.php';
$mail = new Mailer();
